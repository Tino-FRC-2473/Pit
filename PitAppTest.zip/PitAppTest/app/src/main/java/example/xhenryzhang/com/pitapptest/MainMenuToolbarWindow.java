package example.xhenryzhang.com.pitapptest;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.DefaultCompany.ModelDisplay3d.UnityPlayerActivity;

public class MainMenuToolbarWindow extends AppCompatActivity {

    ListView mainMenu;
    Button back;
    String[] entries; // array holding the menu entry names (team info, robot model, etc.)
    String[] descriptions; // array holding descriptions for each menu entry name
    Intent openInfoMenu;
    Intent open3DModel;
    Intent openStatistics;
    Intent openSponsors;
    Intent openOtherTeamInfo;
    boolean tapRegulator = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu_toolbar_window);

        Resources res = getResources(); // contains all the additional information I put in res
        mainMenu = (ListView) findViewById(R.id.toolsList);
        back = (Button) findViewById(R.id.backButton);

        // make arrays containing text information from the res folder
        entries = res.getStringArray(R.array.options);
        descriptions = res.getStringArray(R.array.descriptions);

        EntriesAdapter menuLayout = new EntriesAdapter(this, entries, descriptions);
        mainMenu.setAdapter(menuLayout);

        // determines what happens when you click on a menu button
        mainMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int menuIndex, long l){
                System.out.println(menuIndex);
                if (menuIndex == 0) {
                    openInfoMenu = new Intent(getApplicationContext(), TeamInfoWindow.class);
                    startActivity(openInfoMenu);
                }else if(menuIndex == 1){
                    Intent i = new Intent(getApplicationContext(), UnityPlayerActivity.class);
                    startActivity(i);
                }else if(menuIndex == 4){
                    // add more
                    openStatistics = new Intent(getApplicationContext(), StatisticsWindow.class);
                    startActivity(openStatistics);
                }else if (menuIndex == 2){
                    openSponsors = new Intent(getApplicationContext(), SponsorsWindow.class);
                    startActivity(openSponsors);
                }else if (menuIndex == 3){
                    openOtherTeamInfo = new Intent(getApplicationContext(), OtherTeamsWindow.class);
                    startActivity(openOtherTeamInfo);
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v){
                tapRegulator = !tapRegulator;
                if (tapRegulator == true){
                    finish();
                }
                overridePendingTransition(R.anim.animation3,R.anim.animation4);
            }
        });
    }
}
