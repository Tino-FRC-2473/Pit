package example.xhenryzhang.com.pitapptest;

import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Intent openMainMenu;
    TextView title;
    TextView pressStart;
    Boolean tapRegulator = false;
    //VideoView mainMenuVideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // contains the font file
        Typeface typeface = Typeface.createFromAsset(getAssets(), "Fonts/RobotoCondensed-Bold.ttf");

        title = (TextView) findViewById(R.id.titles);
        title.setTypeface(typeface);

        pressStart = (TextView) findViewById(R.id.startText);
        pressStart.setTypeface(typeface);

        // animates flashing text
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(300); //You can manage the time of the blink with this parameter
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        pressStart.startAnimation(anim);

        // set up the video (download video file from robotics drive and put it in a new res folder named 'raw'
        // if you want to run this code)
        // Uri videoPlayer = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.calgames);

        // play the video
        //mainMenuVideo.setVideoURI(videoPlayer);
        //mainMenuVideo.start();

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public boolean onTouchEvent(MotionEvent event){
        tapRegulator = !tapRegulator;
        if (tapRegulator == true) {
            // open me
            Bundle slideAnimation = ActivityOptions.makeCustomAnimation(getApplicationContext(), R.anim.animation1
            , R.anim.animation2).toBundle();
            openMainMenu = new Intent(getApplicationContext(), MainMenuToolbarWindow.class);
            startActivity(openMainMenu, slideAnimation);
        }
        return true;
    }

}